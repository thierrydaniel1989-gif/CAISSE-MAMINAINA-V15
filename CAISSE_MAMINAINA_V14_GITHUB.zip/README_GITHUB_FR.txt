CAISSE MAMINAINA - VERSION 1.4 - IMPRESSION RESEAU NATIF

Cette archive contient le projet Android/Capacitor, le module Android natif NetworkPrinter et le workflow GitHub Actions.

IMPRESSION XPRINTER XP-80T (Wi-Fi direct)
- L'impression réseau est réalisée dans Android en Java via un socket TCP natif, port 9100 par défaut.
- Le plugin natif expose testConnection, print et scanNetwork.
- scanNetwork recherche les appareils du sous-réseau Wi-Fi du téléphone qui acceptent le port TCP configuré.
- Le téléphone doit être connecté au Wi-Fi émis par l'imprimante. Garder le Wi-Fi connecté même si Android indique « sans Internet ».
- Attention : 10.10.100.254 peut être l'adresse de la passerelle/du routeur et pas celle de l'imprimante. Utiliser « Rechercher sur le réseau », puis sélectionner l'adresse détectée. Sinon vérifier l'adresse IP imprimée dans la page de configuration réseau de la Xprinter.
- Ne pas utiliser Bluetooth ni le service d'impression Android pour le mode Réseau.

PERMISSIONS
Le manifeste ajoute INTERNET, ACCESS_NETWORK_STATE et ACCESS_WIFI_STATE. Le projet utilise le target SDK fourni par Capacitor 7; si le target SDK est ultérieurement porté à Android 17/API 37, il faudra ajouter la demande runtime ACCESS_LOCAL_NETWORK conformément aux règles Android 17.

FRAIS DE LIVRAISON
La version comprend également le champ facultatif « Frais de livraison » et son inclusion dans le total et les reçus, selon la version source V1.3 fournie.

COMPILATION
1. Décompresser le contenu de cette archive à la racine du dépôt GitHub (pas dans un sous-dossier).
2. Envoyer/committer les fichiers sur la branche main.
3. Ouvrir Actions > Build Caisse MAMINAINA APK > Run workflow.
4. Télécharger l'artefact Caisse-MAMINAINA-APK-v1.4 puis app-debug.apk.
5. Installer la nouvelle APK sur Android. Exporter d'abord une sauvegarde JSON de la caisse.

IMPORTANT
Le code et le workflow sont préparés pour compilation GitHub Actions. La connexion réelle à l'imprimante ne peut être confirmée qu'après installation de l'APK sur le Samsung, connexion au Wi-Fi de la Xprinter et test TCP sur la bonne adresse IP/port.
