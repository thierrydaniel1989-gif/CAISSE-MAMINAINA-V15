package com.maminaina.caisse;


import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Inet4Address;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

@CapacitorPlugin(name = "NetworkPrinter")
public class NetworkPrinterPlugin extends Plugin {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ExecutorService scanExecutor = Executors.newFixedThreadPool(32);

    private Socket openSocket(String host, int port, int timeoutMs) throws Exception {
        Socket socket = new Socket();
        socket.setTcpNoDelay(true);
        socket.setKeepAlive(true);
        socket.connect(new InetSocketAddress(host, port), timeoutMs);
        socket.setSoTimeout(5000);
        return socket;
    }

    @PluginMethod
    public void testConnection(PluginCall call) {
        String host = call.getString("host");
        Integer port = call.getInt("port", 9100);
        if (host == null || host.trim().isEmpty()) {
            call.reject("Adresse IP de l'imprimante manquante");
            return;
        }
        final String targetHost = host.trim();
        final int targetPort = (port == null ? 9100 : port);
        executor.execute(() -> {
            try (Socket socket = openSocket(targetHost, targetPort, 3000)) {
                JSObject result = new JSObject();
                result.put("connected", true);
                result.put("host", targetHost);
                result.put("port", targetPort);
                call.resolve(result);
            } catch (Exception e) {
                String reason = e instanceof SocketTimeoutException ? "délai dépassé : vérifie l'adresse IP, le port et le Wi-Fi" : e.getMessage();
                call.reject("Connexion TCP impossible vers " + targetHost + ":" + targetPort + " — " + reason, e);
            }
        });
    }

    @PluginMethod
    public void print(PluginCall call) {
        String host = call.getString("host");
        Integer port = call.getInt("port", 9100);
        JSArray data = call.getArray("data");
        if (host == null || host.trim().isEmpty() || data == null) {
            call.reject("Adresse IP ou données d'impression manquantes");
            return;
        }
        final String targetHost = host.trim();
        final int targetPort = (port == null ? 9100 : port);
        executor.execute(() -> {
            try (Socket socket = openSocket(targetHost, targetPort, 5000)) {
                OutputStream out = socket.getOutputStream();
                byte[] bytes = new byte[data.length()];
                for (int i = 0; i < data.length(); i++) bytes[i] = (byte) (data.optInt(i, 0) & 0xFF);
                out.write(bytes);
                out.flush();
                socket.shutdownOutput();
                JSObject result = new JSObject();
                result.put("sent", bytes.length);
                result.put("host", targetHost);
                result.put("port", targetPort);
                call.resolve(result);
            } catch (Exception e) {
                String reason = e instanceof SocketTimeoutException ? "délai dépassé" : e.getMessage();
                call.reject("Échec de l'envoi ESC/POS vers " + targetHost + ":" + targetPort + " — " + reason, e);
            }
        });
    }

    // Recherche les hôtes du sous-réseau Wi-Fi qui acceptent le port d'impression TCP.
    @PluginMethod
    public void scanNetwork(PluginCall call) {
        Integer requestedPort = call.getInt("port", 9100);
        final int port = requestedPort == null ? 9100 : requestedPort;
        if (port < 1 || port > 65535) {
            call.reject("Port TCP invalide");
            return;
        }
        executor.execute(() -> {
            try {
                int local = 0;
                int prefix = -1;
                Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
                while (interfaces != null && interfaces.hasMoreElements() && prefix < 0) {
                    NetworkInterface ni = interfaces.nextElement();
                    if (!ni.isUp() || ni.isLoopback()) continue;
                    String ifName = ni.getName().toLowerCase();
                    // Priorité aux interfaces Wi-Fi/Wi-Fi Direct, jamais au réseau mobile.
                    if (!(ifName.contains("wlan") || ifName.contains("wifi") || ifName.contains("p2p"))) continue;
                    for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                        InetAddress addr = ia.getAddress();
                        short pfx = ia.getNetworkPrefixLength();
                        if (addr instanceof Inet4Address && !addr.isLoopbackAddress() && pfx >= 1 && pfx <= 30) {
                            byte[] b = addr.getAddress();
                            local = ((b[0] & 0xff) << 24) | ((b[1] & 0xff) << 16) | ((b[2] & 0xff) << 8) | (b[3] & 0xff);
                            prefix = pfx;
                            break;
                        }
                    }
                }
                if (prefix < 0) throw new Exception("Aucune adresse IPv4 Wi-Fi détectée. Connecte le téléphone au Wi-Fi direct de l'imprimante et garde le Wi-Fi activé.");
                int mask = (int) (0xffffffffL << (32 - prefix));
                int network = local & mask;
                int broadcast = network | ~mask;
                long count = (broadcast & 0xffffffffL) - (network & 0xffffffffL) - 1;
                if (count < 1 || count > 1022) throw new Exception("Sous-réseau Wi-Fi non pris en charge pour le scan automatique");

                CompletionService<String> completion = new ExecutorCompletionService<>(scanExecutor);
                int submitted = 0;
                for (int offset = 1; offset <= count; offset++) {
                    final int address = network + offset;
                    if (address == local) continue;
                    final String ip = intToIp(address);
                    completion.submit(() -> {
                        try (Socket s = openSocket(ip, port, 450)) { return ip; }
                        catch (Exception ignored) { return null; }
                    });
                    submitted++;
                }
                List<String> found = new ArrayList<>();
                for (int i = 0; i < submitted; i++) {
                    Future<String> f = completion.poll(8, TimeUnit.SECONDS);
                    if (f == null) break;
                    String ip = f.get();
                    if (ip != null) found.add(ip);
                }
                Collections.sort(found);
                JSArray ips = new JSArray();
                for (String ip : found) ips.put(ip);
                JSObject result = new JSObject();
                result.put("ips", ips);
                result.put("phoneIp", intToIp(local));
                result.put("port", port);
                call.resolve(result);
            } catch (Exception e) {
                call.reject("Recherche réseau impossible : " + e.getMessage(), e);
            }
        });
    }

    private String intToIp(int value) {
        return ((value >> 24) & 0xff) + "." + ((value >> 16) & 0xff) + "." + ((value >> 8) & 0xff) + "." + (value & 0xff);
    }
}
